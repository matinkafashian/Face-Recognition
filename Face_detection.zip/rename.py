import os

folder = "known_faces"
files = os.listdir(folder)
files = [f for f in files if f.lower().endswith(('.jpg', '.jpeg', '.png'))]

for i, filename in enumerate(files):
    ext = os.path.splitext(filename)[1]
    new_name = f"matin kafashian{i+1}{ext}"
    os.rename(os.path.join(folder, filename), os.path.join(folder, new_name))
    print(f"Renamed {filename} → {new_name}")
