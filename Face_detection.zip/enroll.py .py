import os, pickle, cv2, faiss, numpy as np
from insightface.app import FaceAnalysis

KNOWN_DIR = "known_faces"
DB_FILE   = "faces.faiss"

app = FaceAnalysis(name="buffalo_l")
app.prepare(ctx_id=0, det_size=(640, 640))

embeds, labels = [], []

name_map = {
    "ronaldo": "Ronaldo",
    "messi": "Messi",
    "matin": "Matin Kafashian"
}

for fn in sorted(os.listdir(KNOWN_DIR)):
    if not fn.lower().endswith((".jpg", ".jpeg", ".png")):
        continue
    img = cv2.imread(os.path.join(KNOWN_DIR, fn))
    faces = app.get(img)
    if not faces:
        print("⚠️ no face in", fn)
        continue
    emb = faces[0].embedding
    emb = emb / np.linalg.norm(emb)
    embeds.append(emb.astype("float32"))

    fn_lower = fn.lower()
    name = next((v for k,v in name_map.items() if k in fn_lower), "Unknown")
    labels.append(name)

if not embeds:
    raise RuntimeError("no faces found!")

faiss_index = faiss.IndexFlatIP(512)
faiss_index.add(np.stack(embeds))

with open(DB_FILE, "wb") as f:
    pickle.dump((faiss_index, labels), f)

print(f"✅  Saved {len(labels)} embeddings to {DB_FILE}")
