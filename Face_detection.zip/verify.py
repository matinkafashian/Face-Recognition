import cv2, numpy as np, faiss, pickle, sys, os
from insightface.app import FaceAnalysis

# ---------- load DB ----------
with open("faces.faiss", "rb") as f:
    index, names = pickle.load(f)

# ---------- InsightFace ----------
app = FaceAnalysis(name="buffalo_l")
app.prepare(ctx_id=0, det_size=(640, 640))

def recognize(path, thr=0.35):               # thr≈۱−cosine
    if not os.path.isfile(path):
        return "file not found"

    img = cv2.imread(path)
    faces = app.get(img)
    if not faces:
        return "no face"
    emb = faces[0].embedding
    emb = emb / np.linalg.norm(emb)          # ⬅️ نرمال‌سازی

    D, I = index.search(np.expand_dims(emb.astype("float32"), 0), 1)
    cos_sim = D[0][0]                        # محدوده 0..1
    print(f"Cosine similarity: {cos_sim:.3f}")

    if cos_sim > 1 - thr:                    # شباهت کافی؟
        return names[I[0][0]]
    return "Unknown"

if __name__ == "__main__":
    test_path = sys.argv[1] if len(sys.argv) > 1 else "uploads/test.jpg"
    print(recognize(test_path))
