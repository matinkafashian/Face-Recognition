"""Flask web-app: آپلود → Ronaldo / Messi / Unknown"""
import os, uuid, pickle, cv2, faiss, numpy as np
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory
from werkzeug.utils import secure_filename
from insightface.app import FaceAnalysis

UPLOAD_DIR = "uploads"
DB_FILE    = "faces.faiss"
ALLOWED_EXT = {"png", "jpg", "jpeg"}
THR = 0.35

app = Flask(__name__)
app.config.update(SECRET_KEY="face-secret", UPLOAD_FOLDER=UPLOAD_DIR)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# --- load DB ---
with open(DB_FILE, "rb") as f:
    faiss_index, label_list = pickle.load(f)

face_app = FaceAnalysis(name="buffalo_l")
face_app.prepare(ctx_id=0, det_size=(640, 640))

# ---------- helpers ----------
def allowed(fname): return "." in fname and fname.rsplit(".",1)[1].lower() in ALLOWED_EXT

def recognise(img_path):
    img = cv2.imread(img_path)
    faces = face_app.get(img)
    if not faces:
        return "No face", 0.0
    emb = faces[0].embedding
    emb = emb/np.linalg.norm(emb)
    D,I = faiss_index.search(np.expand_dims(emb.astype("float32"),0),1)
    sim = D[0][0]                    # 0..1
    if sim > 1-THR:
        return label_list[I[0][0]], sim
    return "Unknown", sim

# ---------- routes ----------
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files.get("image")
    if not file or file.filename=="":
        flash("Choose an image first","warning"); return redirect(url_for("home"))
    if not allowed(file.filename):
        flash("File type not allowed","danger");  return redirect(url_for("home"))

    filename = secure_filename(file.filename)
    unique   = f"{uuid.uuid4().hex}_{filename}"
    path     = os.path.join(UPLOAD_DIR, unique)
    file.save(path)

    person,score = recognise(path)
    return redirect(url_for("result", name=person, conf=f"{score:.2f}", img=unique))

@app.route("/result")
def result():
    return render_template("result.html",
                           name=request.args.get("name"),
                           conf=request.args.get("conf"),
                           img=request.args.get("img"))

@app.route("/uploads/<path:filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename)

if __name__=="__main__":
    app.run(debug=True)
